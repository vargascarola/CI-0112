var searchData=
[
  ['esempate_0',['esEmpate',['../class_conecta_cuatro.html#a79386ff2b4093788b660fdb6484f9e3a',1,'ConectaCuatro.esEmpate()'],['../class_tic_tac_toe.html#a485fac0d7a44d1eb27e6e4beeeb5a625',1,'TicTacToe.esEmpate()']]],
  ['esganador_1',['esGanador',['../class_conecta_cuatro.html#a834665e017b10a692b25aec481a80fbd',1,'ConectaCuatro.esGanador()'],['../class_tic_tac_toe.html#a08d7ae4699ec9a5771a07336e60c05c3',1,'TicTacToe.esGanador()']]],
  ['esjuegoterminado_2',['esJuegoTerminado',['../class_conecta_cuatro.html#ad3b1d69eb50feb8a611a3145b510b5fd',1,'ConectaCuatro.esJuegoTerminado()'],['../class_tic_tac_toe.html#afe16c61cccdc9852959867bfc0546a8e',1,'TicTacToe.esJuegoTerminado()']]]
];
