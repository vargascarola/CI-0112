var searchData=
[
  ['juegocontrolador_0',['JuegoControlador',['../class_juego_controlador.html#ae838f7b0a58d8895d884ef9a34f899d2',1,'JuegoControlador']]],
  ['jugar_1',['jugar',['../class_juego_controlador.html#a81d5036e41e18521a2a65606938c3e20',1,'JuegoControlador']]],
  ['jugarconectacuatro_2',['jugarConectaCuatro',['../class_juego_controlador.html#a5f727df19176c467c24147bdfcd230f2',1,'JuegoControlador']]],
  ['jugartictactoe_3',['jugarTicTacToe',['../class_juego_controlador.html#aecd9e9f0ac51b1c4ed18170f8eced9a9',1,'JuegoControlador']]]
];
