var searchData=
[
  ['hacermovimiento_0',['hacerMovimiento',['../class_conecta_cuatro.html#a9e86f9b8a8692d4f5529d72e6cc616d4',1,'ConectaCuatro.hacerMovimiento()'],['../class_tic_tac_toe.html#a47a95cf9a4b917fd7500dd91a99c7e11',1,'TicTacToe.hacerMovimiento()']]]
];
