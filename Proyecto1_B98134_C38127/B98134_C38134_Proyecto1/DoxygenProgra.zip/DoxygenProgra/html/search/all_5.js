var searchData=
[
  ['juegocontrolador_0',['JuegoControlador',['../class_juego_controlador.html',1,'JuegoControlador'],['../class_juego_controlador.html#ae838f7b0a58d8895d884ef9a34f899d2',1,'JuegoControlador.JuegoControlador()']]],
  ['juegocontrolador_2ejava_1',['JuegoControlador.java',['../_juego_controlador_8java.html',1,'']]],
  ['jugar_2',['jugar',['../class_juego_controlador.html#a81d5036e41e18521a2a65606938c3e20',1,'JuegoControlador']]],
  ['jugarconectacuatro_3',['jugarConectaCuatro',['../class_juego_controlador.html#a5f727df19176c467c24147bdfcd230f2',1,'JuegoControlador']]],
  ['jugartictactoe_4',['jugarTicTacToe',['../class_juego_controlador.html#aecd9e9f0ac51b1c4ed18170f8eced9a9',1,'JuegoControlador']]]
];
