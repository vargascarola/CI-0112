var searchData=
[
  ['getjugadoractual_0',['getJugadorActual',['../class_conecta_cuatro.html#abf30ecc919eadc766cdf944da4e02c54',1,'ConectaCuatro.getJugadorActual()'],['../class_tic_tac_toe.html#a527870e9689015e90598722fe4c40261',1,'TicTacToe.getJugadorActual()']]]
];
