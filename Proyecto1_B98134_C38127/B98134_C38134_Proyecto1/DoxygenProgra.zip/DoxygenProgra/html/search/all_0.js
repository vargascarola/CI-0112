var searchData=
[
  ['cambiarjugador_0',['cambiarJugador',['../class_conecta_cuatro.html#a8eb816dcc298a60f4e23721fe39616e8',1,'ConectaCuatro.cambiarJugador()'],['../class_tic_tac_toe.html#a5160a336c6d07673df2dddb0e7317dd8',1,'TicTacToe.cambiarJugador()']]],
  ['conectacuatro_1',['ConectaCuatro',['../class_conecta_cuatro.html',1,'ConectaCuatro'],['../class_conecta_cuatro.html#aa984bf23fbea340e47f807b01651ffde',1,'ConectaCuatro.ConectaCuatro()']]],
  ['conectacuatro_2ejava_2',['ConectaCuatro.java',['../_conecta_cuatro_8java.html',1,'']]]
];
