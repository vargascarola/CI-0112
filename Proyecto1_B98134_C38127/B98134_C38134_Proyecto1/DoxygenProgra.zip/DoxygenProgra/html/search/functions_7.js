var searchData=
[
  ['procesarentradausuario_0',['procesarEntradaUsuario',['../class_juego_controlador.html#ab0acd17f8e12fc1b6a3512be4944254f',1,'JuegoControlador']]]
];
