var searchData=
[
  ['iniciarjuego_0',['iniciarJuego',['../class_conecta_cuatro.html#a47c39336175a1012dccdc832b09c0326',1,'ConectaCuatro.iniciarJuego()'],['../class_tic_tac_toe.html#a7c26ae0c8403e4581fdb60832c76b62f',1,'TicTacToe.iniciarJuego()']]]
];
