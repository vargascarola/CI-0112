var searchData=
[
  ['main_0',['main',['../class_juego_controlador.html#abc73f907e0183621df2ef59a84da2d37',1,'JuegoControlador']]],
  ['mostrarmenu_1',['mostrarMenu',['../class_juego_controlador.html#a419dd815a9cc88b9268fcbea56593f8d',1,'JuegoControlador']]],
  ['mostrartablero_2',['mostrarTablero',['../class_conecta_cuatro.html#a82dc0f21d317c55aacbc8c7e30caaa08',1,'ConectaCuatro.mostrarTablero()'],['../class_tic_tac_toe.html#ac9abb8c4a54c92f5270c7292299878da',1,'TicTacToe.mostrarTablero()']]]
];
