var searchData=
[
  ['seleccionarjuego_0',['seleccionarJuego',['../class_juego_controlador.html#a381692340ba58e17ec272eb2c5e05100',1,'JuegoControlador']]]
];
