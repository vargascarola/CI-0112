var searchData=
[
  ['conectacuatro_0',['ConectaCuatro',['../class_conecta_cuatro.html',1,'']]]
];
