var class_juego_controlador =
[
    [ "JuegoControlador", "class_juego_controlador.html#ae838f7b0a58d8895d884ef9a34f899d2", null ],
    [ "jugar", "class_juego_controlador.html#a81d5036e41e18521a2a65606938c3e20", null ],
    [ "jugarConectaCuatro", "class_juego_controlador.html#a5f727df19176c467c24147bdfcd230f2", null ],
    [ "jugarTicTacToe", "class_juego_controlador.html#aecd9e9f0ac51b1c4ed18170f8eced9a9", null ],
    [ "mostrarMenu", "class_juego_controlador.html#a419dd815a9cc88b9268fcbea56593f8d", null ],
    [ "procesarEntradaUsuario", "class_juego_controlador.html#ab0acd17f8e12fc1b6a3512be4944254f", null ],
    [ "seleccionarJuego", "class_juego_controlador.html#a381692340ba58e17ec272eb2c5e05100", null ]
];