var class_conecta_cuatro =
[
    [ "ConectaCuatro", "class_conecta_cuatro.html#aa984bf23fbea340e47f807b01651ffde", null ],
    [ "cambiarJugador", "class_conecta_cuatro.html#a8eb816dcc298a60f4e23721fe39616e8", null ],
    [ "esEmpate", "class_conecta_cuatro.html#a79386ff2b4093788b660fdb6484f9e3a", null ],
    [ "esGanador", "class_conecta_cuatro.html#a834665e017b10a692b25aec481a80fbd", null ],
    [ "esJuegoTerminado", "class_conecta_cuatro.html#ad3b1d69eb50feb8a611a3145b510b5fd", null ],
    [ "getJugadorActual", "class_conecta_cuatro.html#abf30ecc919eadc766cdf944da4e02c54", null ],
    [ "hacerMovimiento", "class_conecta_cuatro.html#a9e86f9b8a8692d4f5529d72e6cc616d4", null ],
    [ "iniciarJuego", "class_conecta_cuatro.html#a47c39336175a1012dccdc832b09c0326", null ],
    [ "mostrarTablero", "class_conecta_cuatro.html#a82dc0f21d317c55aacbc8c7e30caaa08", null ]
];