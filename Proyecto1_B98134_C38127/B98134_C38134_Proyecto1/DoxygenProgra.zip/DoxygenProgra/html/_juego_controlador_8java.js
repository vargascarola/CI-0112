var _juego_controlador_8java =
[
    [ "JuegoControlador", "class_juego_controlador.html", "class_juego_controlador" ]
];