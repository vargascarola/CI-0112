var class_tic_tac_toe =
[
    [ "TicTacToe", "class_tic_tac_toe.html#a416ce299c10ec6b7a4c050aa87b62eb1", null ],
    [ "cambiarJugador", "class_tic_tac_toe.html#a5160a336c6d07673df2dddb0e7317dd8", null ],
    [ "esEmpate", "class_tic_tac_toe.html#a485fac0d7a44d1eb27e6e4beeeb5a625", null ],
    [ "esGanador", "class_tic_tac_toe.html#a08d7ae4699ec9a5771a07336e60c05c3", null ],
    [ "esJuegoTerminado", "class_tic_tac_toe.html#afe16c61cccdc9852959867bfc0546a8e", null ],
    [ "getJugadorActual", "class_tic_tac_toe.html#a527870e9689015e90598722fe4c40261", null ],
    [ "hacerMovimiento", "class_tic_tac_toe.html#a47a95cf9a4b917fd7500dd91a99c7e11", null ],
    [ "iniciarJuego", "class_tic_tac_toe.html#a7c26ae0c8403e4581fdb60832c76b62f", null ],
    [ "mostrarTablero", "class_tic_tac_toe.html#ac9abb8c4a54c92f5270c7292299878da", null ]
];