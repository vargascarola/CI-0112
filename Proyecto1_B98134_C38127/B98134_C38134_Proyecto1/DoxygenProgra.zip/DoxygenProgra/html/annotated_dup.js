var annotated_dup =
[
    [ "ConectaCuatro", "class_conecta_cuatro.html", "class_conecta_cuatro" ],
    [ "JuegoControlador", "class_juego_controlador.html", "class_juego_controlador" ],
    [ "TicTacToe", "class_tic_tac_toe.html", "class_tic_tac_toe" ]
];