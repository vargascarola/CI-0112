var files_dup =
[
    [ "ConectaCuatro.java", "_conecta_cuatro_8java.html", "_conecta_cuatro_8java" ],
    [ "JuegoControlador.java", "_juego_controlador_8java.html", "_juego_controlador_8java" ],
    [ "TicTacToe.java", "_tic_tac_toe_8java.html", "_tic_tac_toe_8java" ]
];